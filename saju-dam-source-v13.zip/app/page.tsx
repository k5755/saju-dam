export default function Page(){return <main><a href="/">사주담으로 이동</a></main>;}
