import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "사주담 — 나를 이해하는 사주",
  description: "사주 계산과 AI 해석으로 나를 돌아보는 시간.",
  other: {

  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">{children}</body>
    </html>
  );
}
